// src/db.ts
import { MongoClient } from "mongodb";

const uri = "mongodb://127.0.0.1:27017"; // Local MongoDB connection
const client = new MongoClient(uri);

export async function connectToDatabase() {
  try {
    await client.connect();
    console.log("✅ Connected to MongoDB");
    return client.db("node_assignment"); // This will use/create 'node_assignment' DB
  } catch (error) {
    console.error("❌ Failed to connect to MongoDB:", error);
    process.exit(1);
  }
}
