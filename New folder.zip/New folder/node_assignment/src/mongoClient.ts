// src/mongoClient.ts
import { MongoClient } from "mongodb";

// Replace this URI with your actual MongoDB URI
const uri = "mongodb://localhost:27017";
export const client = new MongoClient(uri);

// Export database name
export const dbName = "node_assignment";
