// src/models.ts

export interface Address {
  street: string;
  suite: string;
  city: string;
  zipcode: string;
  geo: {
    lat: string;
    lng: string;
  };
}

export interface Company {
  name: string;
  catchPhrase: string;
  bs: string;
}

export interface User {
  id: number;
  name: string;
  username: string;
  email: string;
  address: Address;
  phone: string;
  website: string;
  company: Company;
  posts: Post[];  // Array of posts for each user
}

export interface Post {
  id: number;
  userId: number;  // The user ID to which this post belongs
  title: string;
  body: string;
  comments: Comment[];  // Array of comments for this post
}

export interface Comment {
  id: number;
  postId: number;  // The post ID to which this comment belongs
  name: string;
  email: string;
  body: string;
}
