import axios from "axios";
import { client, dbName } from "./mongoClient";

interface User {
  id: number;
  name: string;
  username: string;
  email: string;
  phone: string;
  website: string;
}

interface Post {
  id: number;
  userId: number;
  title: string;
  body: string;
}

interface Comment {
  id: number;
  postId: number;
  name: string;
  email: string;
  body: string;
}

const loadData = async () => {
  try {
    const usersResponse = await axios.get<User[]>("https://jsonplaceholder.typicode.com/users");
    const postsResponse = await axios.get<Post[]>("https://jsonplaceholder.typicode.com/posts");
    const commentsResponse = await axios.get<Comment[]>("https://jsonplaceholder.typicode.com/comments");

    const users = usersResponse.data;
    const posts = postsResponse.data;
    const comments = commentsResponse.data;

    await client.connect();
    const db = client.db(dbName);

    await db.collection("users").insertMany(users);
    await db.collection("posts").insertMany(posts);
    await db.collection("comments").insertMany(comments);

    console.log("✅ Users, Posts, and Comments loaded to MongoDB.");
  } catch (err) {
    console.error("❌ Failed to load data:", err);
  } finally {
    await client.close();
  }
};

loadData();
