import { createServer, IncomingMessage, ServerResponse } from "http";
import { client, dbName } from "./mongoClient";
import { URL } from "url";

const port = 3000;

const server = createServer(async (req: IncomingMessage, res: ServerResponse) => {
  const url = new URL(req.url || "", `http://${req.headers.host}`);
  const path = url.pathname;
  const method = req.method;

  await client.connect();
  const db = client.db(dbName);

  res.setHeader("Content-Type", "application/json");

  // GET /users
  if (method === "GET" && path === "/users") {
    const users = await db.collection("users").find().toArray();
    res.end(JSON.stringify(users));
  }

  // GET /posts
  else if (method === "GET" && path === "/posts") {
    const posts = await db.collection("posts").find().toArray();
    res.end(JSON.stringify(posts));
  }

  // GET /comments
  else if (method === "GET" && path === "/comments") {
    const comments = await db.collection("comments").find().toArray();
    res.end(JSON.stringify(comments));
  }

  // GET /users/:id/posts
  else if (method === "GET" && /^\/users\/\d+\/posts$/.test(path)) {
    const userId = parseInt(path.split("/")[2]);
    const posts = await db.collection("posts").find({ userId }).toArray();
    res.end(JSON.stringify(posts));
  }

  // GET /posts/:id/comments
  else if (method === "GET" && /^\/posts\/\d+\/comments$/.test(path)) {
    const postId = parseInt(path.split("/")[2]);
    const comments = await db.collection("comments").find({ postId }).toArray();
    res.end(JSON.stringify(comments));
  }

  else {
    res.statusCode = 404;
    res.end(JSON.stringify({ error: "Not Found" }));
  }
});

server.listen(port, () => {
  console.log(`🚀 Server running at http://localhost:${port}`);
});
